from pycker.gui import main
main()
